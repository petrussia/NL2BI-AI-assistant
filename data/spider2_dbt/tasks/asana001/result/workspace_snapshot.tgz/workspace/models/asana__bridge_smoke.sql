-- Bridge dry-run smoke model: uses no sources, only constants.
-- Confirms apply + dbt deps + dbt run + dbt test path is wired.
SELECT 1 AS bridge_smoke_marker
