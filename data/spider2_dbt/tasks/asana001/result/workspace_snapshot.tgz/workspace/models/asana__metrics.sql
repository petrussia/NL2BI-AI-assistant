with task as (
    select *
    from {{ ref('asana__task') }}
),

completed_tasks as (
    select
        task_id,
        completed_at
    from task
    where is_completed = true
),

open_tasks as (
    select
        task_id,
        created_at
    from task
    where is_completed = false
),

avg_close_time as (
    select
        avg(completed_at - created_at) as avg_close_duration
    from completed_tasks
)

select
    (select count(*) from open_tasks) as open_tasks_count,
    (select count(*) from completed_tasks) as completed_tasks_count,
    (select avg_close_duration from avg_close_time) as avg_close_time
