# Practice Tasks Mapping

| Task | Evidence | Status |
|---|---|---|
| Notebook & helper audit | outputs/logs/local_notebook_audit.md, outputs/logs/local_helper_script_audit.md | completed |
| Runtime & Drive audit | outputs/logs/runtime_project_root_audit.md | completed |
| Spider asset recovery | outputs/logs/b0_blockers_audit.md, data/spider/SOURCE_AND_AUDIT.md | completed |
| B0 loader validation | outputs/logs/b0_loader_subsets_audit.md | completed |
| B0 smoke10 inference | outputs/predictions/b0_spider_smoke10_predictions.jsonl | completed |
| B0 EX evaluation | outputs/metrics/b0_spider_smoke10_metrics.csv | completed |
| B0 examples / errors | outputs/tables/b0_spider_smoke10_examples.md, outputs/tables/b0_spider_smoke10_error_cases.md | completed |
| B0 physical reverification | outputs/logs/b0_physical_recheck.md | completed |
| B1 schema linking implementation | repo/src/evaluation/baselines.py, outputs/tables/b1_schema_linking_examples.md | completed |
| B1 schema linking audit | outputs/logs/b1_schema_linking_audit.md | completed |
| B1 smoke10 inference | outputs/predictions/b1_spider_smoke10_predictions.jsonl | completed |
| B1 EX evaluation | outputs/metrics/b1_spider_smoke10_metrics.csv | completed |
| B1 examples / errors | outputs/tables/b1_spider_smoke10_examples.md, outputs/tables/b1_spider_smoke10_error_cases.md | completed |
| B0 vs B1 comparison | outputs/tables/b0_vs_b1_smoke10_comparison.csv, outputs/tables/b0_vs_b1_smoke10_comparison.md, outputs/plots/b0_vs_b1_smoke10_bar.png, outputs/tables/b0_vs_b1_case_diff.md | completed |
| smoke25 / B2 | — | not started |
| Fine-tuning | — | not started |
