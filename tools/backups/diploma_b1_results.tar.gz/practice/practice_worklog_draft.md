# Practice Worklog Draft

## Current State (updated 2026-04-25T15:46:39.806425+00:00)

### B0 (full schema baseline)
- Status: completed
- Subset: Spider smoke10
- Model: Qwen/Qwen2.5-Coder-7B-Instruct
- Quantization: device_map_auto_no_4bit_fallback
- EX: 1.0
- Executable: 10 / 10
- Predictions: `outputs/predictions/b0_spider_smoke10_predictions.jsonl`
- Metrics: `outputs/metrics/b0_spider_smoke10_metrics.csv`
- Physically reverified: see `outputs/logs/b0_physical_recheck.md`

### B1 (reduced schema via lexical schema linking)
- Status: completed
- Subset: Spider smoke10
- Model: Qwen/Qwen2.5-Coder-7B-Instruct
- Quantization: 4bit_bitsandbytes_config
- Schema strategy: lexical_schema_linking
- Avg reduction ratio: 0.475
- EX: 1.0
- Executable: 10 / 10
- Schema linking examples: `outputs/tables/b1_schema_linking_examples.md`
- Schema linking audit: `outputs/logs/b1_schema_linking_audit.md`
- Predictions: `outputs/predictions/b1_spider_smoke10_predictions.jsonl`
- Metrics: `outputs/metrics/b1_spider_smoke10_metrics.csv`

### Comparison
- CSV: `outputs/tables/b0_vs_b1_smoke10_comparison.csv`
- MD: `outputs/tables/b0_vs_b1_smoke10_comparison.md`
- Plot: `outputs/plots/b0_vs_b1_smoke10_bar.png`
- Case diff: `outputs/tables/b0_vs_b1_case_diff.md`

Fine-tuning: not started (out of scope for this iteration).
