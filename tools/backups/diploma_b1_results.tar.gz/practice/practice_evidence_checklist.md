# Practice Evidence Checklist

## Audits
- [x] Local notebook audit
- [x] Local helper script audit
- [x] Runtime/project root audit
- [x] B0 blockers audit
- [x] Spider source audit
- [x] B0 physical recheck

## B0 (Spider smoke10)
- [x] Predictions saved
- [x] Metrics saved
- [x] Summary saved
- [x] Run log saved
- [x] Error cases saved
- [x] Examples saved

## B1 (Spider smoke10)
- [x] Schema linking implemented
- [x] Schema linking examples saved
- [x] Schema linking audit saved
- [x] Predictions saved (with selected_tables, schema_reduction_ratio)
- [x] Metrics saved
- [x] Summary saved
- [x] Run log saved
- [x] Error cases saved
- [x] Examples saved

## B0 vs B1
- [x] Comparison CSV saved
- [x] Comparison MD saved
- [x] Bar plot saved
- [x] Case diff MD saved

## Out of scope (not started)
- [ ] B2 Plan-SQL with retrieval
- [ ] smoke25 / dev full
- [ ] Fine-tuning

Checked at: 2026-04-25T15:46:39.806425+00:00
