# Practice Tasks Mapping

Updated 2026-04-25T17:11:14.345702+00:00.

| Task in practice plan | Evidence on Drive | Status |
|---|---|---|
| Notebook + helper script audit | `outputs/logs/local_notebook_audit.md`, `outputs/logs/local_helper_script_audit.md`, `tools/notebook_tooling_audit.md`, `tools/run_cell_changelog.md` | completed |
| Runtime + Drive audit | `outputs/logs/runtime_project_root_audit.md`, `outputs/logs/bridge_status_drive.md` | completed |
| Spider asset acquisition + integrity | `outputs/logs/b0_blockers_audit.md`, `data/spider/SOURCE_AND_AUDIT.md` | completed |
| Loader + smoke subset construction | `outputs/logs/b0_loader_subsets_audit.md`, `outputs/logs/smoke25_subset_audit.md` | completed |
| B0 baseline (full schema, smoke10, smoke25) | `outputs/predictions/b0_spider_*.jsonl`, `outputs/metrics/b0_spider_*.csv`, `outputs/tables/b0_spider_*_summary.csv`, `outputs/tables/b0_spider_*_examples.md`, `outputs/tables/b0_spider_*_error_cases.md`, `outputs/logs/b0_spider_*_runlog.txt` | completed |
| B1 lexical schema linking implementation | `repo/src/evaluation/baselines.py`, `outputs/tables/b1_schema_linking_*examples.md`, `outputs/logs/b1_schema_linking_*audit.md` | completed |
| B1 baseline (reduced schema, smoke10, smoke25) | `outputs/predictions/b1_spider_*.jsonl`, `outputs/metrics/b1_spider_*.csv`, `outputs/tables/b1_spider_*_summary.csv`, `outputs/tables/b1_spider_*_examples.md`, `outputs/tables/b1_spider_*_error_cases.md`, `outputs/logs/b1_spider_*_runlog.txt` | completed |
| B0 vs B1 comparisons | `outputs/tables/b0_vs_b1_smoke{10,25}_comparison.{csv,md}`, `outputs/plots/b0_vs_b1_smoke{10,25}_bar.png`, `outputs/tables/b0_vs_b1_smoke{10,25}_case_diff.md` (smoke25 file is `b0_vs_b1_smoke25_case_diff.md`; smoke10 file is `b0_vs_b1_case_diff.md`) | completed |
| Aggregate progression | `outputs/tables/baseline_progression_smoke10_smoke25.{csv,md}`, `outputs/plots/baseline_progression_smoke10_smoke25.png` | completed |
| Error taxonomy | `outputs/tables/error_taxonomy_smoke25.md`, `outputs/tables/b0_b1_failure_buckets.csv` | completed |
| Bridge tooling for reproducibility | `tools/bridge_status.md`, `tools/exec_remote.py`, notebook cell `AGENT_BRIDGE_SETUP` (id `7f6bca53`) | completed |
| B2 (Plan-SQL, retrieval, validation, repair) | `outputs/logs/b2_readiness_after_smoke25.md`, `outputs/logs/b2_implementation_plan.md` | planned (not started) |
| Fine-tuning | — | out of scope |
| Final practice + thesis writeups | — | deferred |
