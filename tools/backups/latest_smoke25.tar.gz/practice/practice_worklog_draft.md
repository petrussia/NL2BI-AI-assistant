# Practice Worklog Draft

## Current State (updated 2026-04-25T17:11:14.345702+00:00)

### B0 (full schema baseline)
- Status: completed on smoke10 and smoke25
- Subset smoke10: EX = 1.0, executable 10/10
- Subset smoke25: EX = 0.96, executable 25/25
- Model: Qwen/Qwen2.5-Coder-7B-Instruct (4-bit nf4 bitsandbytes), greedy decode
- Predictions: `outputs/predictions/b0_spider_{smoke10,smoke25}_predictions.jsonl`
- Metrics:     `outputs/metrics/b0_spider_{smoke10,smoke25}_metrics.csv`

### B1 (reduced schema via lexical schema linking)
- Status: completed on smoke10 and smoke25
- Schema strategy: lexical token overlap, table_name x2, column_name x1, min_score=0.5, stopwords removed
- Subset smoke10: EX = 1.0, avg reduction = 0.475
- Subset smoke25: EX = 0.96, avg reduction = 0.58
- Predictions: `outputs/predictions/b1_spider_{smoke10,smoke25}_predictions.jsonl` (with selected_tables, schema_reduction_ratio per row)
- Metrics:     `outputs/metrics/b1_spider_{smoke10,smoke25}_metrics.csv`
- Linking artefacts: `outputs/tables/b1_schema_linking_{,smoke25_}examples.md`, `outputs/logs/b1_schema_linking_{,smoke25_}audit.md`

### Comparisons
- smoke10 B0 vs B1: `outputs/tables/b0_vs_b1_smoke10_comparison.{csv,md}`, `outputs/plots/b0_vs_b1_smoke10_bar.png`, case_diff in tables/
- smoke25 B0 vs B1: `outputs/tables/b0_vs_b1_smoke25_comparison.{csv,md}`, `outputs/plots/b0_vs_b1_smoke25_bar.png`, case_diff in tables/
- Aggregate progression: `outputs/tables/baseline_progression_smoke10_smoke25.{csv,md}`, `outputs/plots/baseline_progression_smoke10_smoke25.png`

### Error analysis
- Bucketed: `outputs/tables/error_taxonomy_smoke25.md`
- Counts: `outputs/tables/b0_b1_failure_buckets.csv`

### Tooling for the loop
- Notebook: `notebooks/example.ipynb`
- Helper (legacy SendKeys, fragile in agent context): `scripts/run_colab_notebook.ps1`
- Bridge (Flask in Colab + cloudflared, primary mechanism): cell `7f6bca53` `AGENT_BRIDGE_SETUP`
- Local client: `tools/exec_remote.py` (--code, --code-file, --ls, --download, --health)
- Recheck/snapshot: `tools/notebook_status.py`, `tools/run_cell.py` (fallback)
- Manifests: `tools/tool_manifest.md`, `tools/tooling_readme.md`, `tools/notebook_tooling_audit.md`

### Out of scope for this iteration
- B2 (Plan->SQL with retrieval, validation, repair, exec-guided selection)
- Fine-tuning
- Multi-DB subsets beyond `concert_singer`
- Final practice and thesis chapters (evidence is being collected, writeup deferred)
