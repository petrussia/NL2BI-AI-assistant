# Practice Evidence Checklist

Updated 2026-04-25T17:11:14.345702+00:00.

## Smoke10
- [x] B0 predictions, metrics, summary, runlog, error_cases, examples
- [x] B1 predictions (incl. selected_tables, schema_reduction_ratio), metrics, summary, runlog, error_cases, examples
- [x] B1 schema linking examples + audit
- [x] B0 vs B1 comparison CSV/MD/plot/case_diff

## Smoke25
- [x] B0 predictions, metrics, summary, runlog, error_cases, examples
- [x] B1 predictions, metrics, summary, runlog, error_cases, examples
- [x] B1 schema linking smoke25 examples + audit
- [x] B0 vs B1 smoke25 comparison CSV/MD/plot/case_diff

## Aggregate
- [x] baseline_progression_smoke10_smoke25.csv/md/png
- [x] error_taxonomy_smoke25.md
- [x] b0_b1_failure_buckets.csv

## Tooling evidence
- [x] tools/notebook_tooling_audit.md
- [x] tools/run_cell_changelog.md
- [x] tools/bridge_status.md
- [x] tools/artifact_recheck.md
- [x] tools/tool_manifest.md
- [x] tools/tooling_readme.md

## Out of scope (intentionally not done)
- [ ] B2 Plan-SQL with retrieval
- [ ] Multi-DB subsets, dev-full evaluation
- [ ] Fine-tuning
- [ ] Final practice report writeup
- [ ] Final thesis chapter

## Practice tasks mapping
- See `practice/practice_tasks_mapping.md` for which task in the practice plan each artefact addresses.
