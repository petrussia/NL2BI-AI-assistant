# Practice Figure Index

Updated 2026-04-25T17:11:14.345702+00:00.

| Path | Caption / role | Use |
|---|---|---|
| `outputs/plots/b0_vs_b1_smoke10_bar.png` | EX comparison B0 vs B1 on Spider smoke10 (n=10) | Section: smoke10 results |
| `outputs/plots/b0_vs_b1_smoke25_bar.png` | EX comparison B0 vs B1 on Spider smoke25 (n=25) | Section: smoke25 results |
| `outputs/plots/baseline_progression_smoke10_smoke25.png` | Aggregate EX progression across baselines and subsets | Section: progression analysis |

All plots are matplotlib bar charts at 140 DPI, generated reproducibly from the metrics CSVs.
