# Practice Table Index

Updated 2026-04-25T17:11:14.345702+00:00.

## Numeric tables (CSV)
| Path | Description |
|---|---|
| `outputs/metrics/b0_spider_smoke10_metrics.csv` | B0 single-row metrics on smoke10 |
| `outputs/metrics/b1_spider_smoke10_metrics.csv` | B1 single-row metrics on smoke10 (incl. avg_reduction_ratio) |
| `outputs/metrics/b0_spider_smoke25_metrics.csv` | B0 single-row metrics on smoke25 |
| `outputs/metrics/b1_spider_smoke25_metrics.csv` | B1 single-row metrics on smoke25 |
| `outputs/tables/b0_spider_smoke10_summary.csv` | B0 smoke10 key/value summary |
| `outputs/tables/b1_spider_smoke10_summary.csv` | B1 smoke10 key/value summary |
| `outputs/tables/b0_spider_smoke25_summary.csv` | B0 smoke25 key/value summary |
| `outputs/tables/b1_spider_smoke25_summary.csv` | B1 smoke25 key/value summary |
| `outputs/tables/b0_vs_b1_smoke10_comparison.csv` | B0 vs B1 head-to-head on smoke10 |
| `outputs/tables/b0_vs_b1_smoke25_comparison.csv` | B0 vs B1 head-to-head on smoke25 |
| `outputs/tables/baseline_progression_smoke10_smoke25.csv` | All four runs side by side |
| `outputs/tables/b0_b1_failure_buckets.csv` | Error bucket counts per baseline (smoke25) |

## Narrative tables (Markdown)
| Path | Description |
|---|---|
| `outputs/tables/b0_spider_smoke{10,25}_examples.md` | First 5 predictions per baseline as a table |
| `outputs/tables/b0_spider_smoke{10,25}_error_cases.md` | Wrong predictions per baseline (≤20) |
| `outputs/tables/b1_spider_smoke{10,25}_examples.md` | Same, with selected_tables column |
| `outputs/tables/b1_spider_smoke{10,25}_error_cases.md` | Same |
| `outputs/tables/b1_schema_linking_examples.md` | Per-question linking output (smoke10) |
| `outputs/tables/b1_schema_linking_smoke25_examples.md` | Per-question linking output (smoke25) |
| `outputs/tables/b0_vs_b1_smoke10_comparison.md` | Counts of improvements / regressions / unchanged on smoke10 |
| `outputs/tables/b0_vs_b1_smoke25_comparison.md` | Same on smoke25 |
| `outputs/tables/b0_vs_b1_case_diff.md` | At least 5 paired cases on smoke10 |
| `outputs/tables/b0_vs_b1_smoke25_case_diff.md` | At least 5 paired cases on smoke25 |
| `outputs/tables/baseline_progression_smoke10_smoke25.md` | Conclusion sentence with deltas |
| `outputs/tables/error_taxonomy_smoke25.md` | Bucket definitions + per-cell breakdown |
