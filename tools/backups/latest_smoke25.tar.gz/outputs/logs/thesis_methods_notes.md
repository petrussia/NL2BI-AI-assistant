# Thesis Methods Notes

Sketches of phrasing the thesis chapter can re-use. Not the chapter itself.

## Setup paragraph
Spider dev split was loaded from the official YALE bundle; we sampled the first 10 and 25 examples to define `smoke_10` and `smoke_25`. Both subsets fall in the `concert_singer` database (4 tables). All inference was run on a single NVIDIA L4 GPU in Google Colab, using `Qwen/Qwen2.5-Coder-7B-Instruct` quantised to 4-bit `nf4` via `bitsandbytes`, with greedy decoding (`do_sample=False`) and `max_new_tokens=192`. Generated SQL was extracted with a regex stripping markdown fences, executed against SQLite with an 8-second timeout via `func_timeout`, and compared to gold by row-multiset equality.

## Baselines paragraph
**B0** receives the full schema as plaintext (`Database: <db>` followed by one line per table listing its columns). **B1** uses the same prompt scaffold but replaces the schema block with a reduced one. Reduction is computed by *lexical schema linking*: for each table and column name, count tokens shared with the question (lowercase, English stopwords removed); each table-name match contributes 2 to the score, each column-name match contributes 1. Tables with score ≥ 0.5 are kept. If no table scores above the threshold, B1 falls back to the full schema (recorded in `fallback_full_schema_count`).

## Results-shape paragraph
On `smoke_10`, B0 and B1 both reach EX=1.0 (10/10 executable). B1 keeps on average **0.475** of the full schema and falls back to full schema on **None** of 10 questions. On `smoke_25`, the corresponding numbers are EX_B0=0.96 and EX_B1=0.96 with avg reduction **0.58** and **6** fallbacks. Side-by-side counts of improvements, regressions, and unchanged outcomes are in `b0_vs_b1_smoke{10,25}_comparison.csv`.

## Limitations paragraph
The schema-linking signal is bounded on this evaluation: smoke10 and smoke25 both probe a single database with four tables, so the upper bound for the linker's contribution is small (irrelevant tables are at most 3 of 4). Stronger conclusions require a multi-DB subset where the linker can rule out *databases*, not just tables. EX is execution-equivalence only; logical equivalence and partial-credit metrics are not computed. The model is loaded in 4-bit; numerical sensitivity to the quantisation scheme is not measured. No retrieval, planner, or repair loop is integrated yet — these belong to B2.

## Tooling paragraph (for the methods appendix)
Inference cells are dispatched via a Cloudflare-tunnelled Flask server inside the Colab kernel (notebook cell `AGENT_BRIDGE_SETUP`, id `7f6bca53`). The local agent talks to the kernel directly over HTTPS; this avoids the focus-race failure of SendKeys-based notebook drivers when the agent's terminal output is rendered in the same VS Code window as the notebook. Predictions are saved incrementally so that a Cloudflare HTTP timeout (~100 s) in the middle of inference does not lose data; the background thread continues writing on Drive after the request returns.
