# Thesis Table Index

Updated 2026-04-25T17:11:14.345702+00:00.

| Suggested table label | Path | Notes |
|---|---|---|
| Tbl. metrics_summary | `outputs/tables/baseline_progression_smoke10_smoke25.csv` | Side-by-side EX, executable_count, avg reduction across all four runs. Camera-ready: rename columns. |
| Tbl. smoke10_compare | `outputs/tables/b0_vs_b1_smoke10_comparison.csv` | B0 vs B1 head-to-head + transition counts on smoke10. |
| Tbl. smoke25_compare | `outputs/tables/b0_vs_b1_smoke25_comparison.csv` | Same on smoke25. |
| Tbl. failure_buckets | `outputs/tables/b0_b1_failure_buckets.csv` | Counts per error bucket across baselines on smoke25. |
| Tbl. linking_examples_smoke10 | `outputs/tables/b1_schema_linking_examples.md` | Per-question linking on smoke10 with selected tables and reduction ratio. |
| Tbl. linking_examples_smoke25 | `outputs/tables/b1_schema_linking_smoke25_examples.md` | Same on smoke25. |
| Tbl. case_diff_smoke25 | `outputs/tables/b0_vs_b1_smoke25_case_diff.md` | ≥5 paired cases with verdict + comment. |

The MD case-diff and examples tables are agent-generated narratives; for the chapter they should be tightened by hand and trimmed to top cases that illustrate the failure modes worth discussing.
