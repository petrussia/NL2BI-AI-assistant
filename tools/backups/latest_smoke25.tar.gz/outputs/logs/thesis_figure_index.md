# Thesis Figure Index

Updated 2026-04-25T17:11:14.345702+00:00.

| Suggested fig label | Path | Caption draft |
|---|---|---|
| Fig. baseline_smoke10 | `outputs/plots/b0_vs_b1_smoke10_bar.png` | "Execution Match (EX) of the full-schema baseline (B0) versus the reduced-schema baseline (B1) on Spider smoke10 (n=10), Qwen2.5-Coder-7B-Instruct, greedy decoding." |
| Fig. baseline_smoke25 | `outputs/plots/b0_vs_b1_smoke25_bar.png` | "EX of B0 versus B1 on Spider smoke25 (n=25); same model and decoding." |
| Fig. progression | `outputs/plots/baseline_progression_smoke10_smoke25.png` | "Aggregate EX progression of B0 and B1 across smoke10 and smoke25." |

All figures rendered at 140 DPI from the corresponding `outputs/metrics/*.csv`. The notebook cells that produce them (and their inputs) are tracked under `tools/remote_scripts/05_smoke25_comparison_and_aggregate.py` (smoke25 plot) and the original B1 pipeline cell (smoke10 plot).
