# Thesis Experiment Inventory

Updated 2026-04-25T17:11:14.345702+00:00.

## Baselines implemented
- **B0** — full-schema NL→SQL prompt, Qwen2.5-Coder-7B-Instruct, 4-bit nf4 bitsandbytes, greedy decoding, max_new_tokens=192. SQL extracted with regex; executed via SQLite with 8 s timeout (`func_timeout`).
- **B1** — same model and decoding, but the schema in the prompt is reduced via lexical schema linking. Token-overlap scoring: table-name match weighted 2, column-name match weighted 1, English stopwords removed, `min_score = 0.5`. Tables with no signal trigger a fallback to the full schema.

## Subsets evaluated
- `data/spider/subsets/smoke_10.json` (n=10, all `concert_singer`)
- `data/spider/subsets/smoke_25.json` (n=25, all `concert_singer`, smoke10 ⊂ smoke25)
- `data/spider/subsets/smoke_50.json` exists on Drive but not yet evaluated.
- Full Spider dev (n=1034) not yet evaluated.

## Metrics computed
- **EX** (Execution Match): predicted SQL executes and returns the same row multiset as gold SQL on the SQLite DB.
- **Executable count**: predicted SQL parses and executes without exception (independent of correctness).
- **Avg schema reduction ratio (B1)**: |selected tables| / |all tables in DB|, averaged across questions.
- **Fallback count (B1)**: questions where no token signal was found and B1 used the full schema.

## Comparisons produced
- B0 vs B1 head-to-head on each subset (CSV, MD narrative, bar plot PNG, case_diff MD).
- Aggregate progression smoke10 → smoke25 (CSV, MD narrative + delta + conclusion sentence, 4-bar PNG).
- Error taxonomy on smoke25 with 8 buckets and per-cell breakdown (MD + counts CSV).

## Reproducibility evidence
- Spider source provenance: `data/spider/SOURCE_AND_AUDIT.md`
- Subset audits: `outputs/logs/b0_loader_subsets_audit.md`, `outputs/logs/smoke25_subset_audit.md`
- Runtime + GPU + library versions: `outputs/logs/runtime_project_root_audit.md`
- Per-run logs: `outputs/logs/{b0,b1}_spider_*_runlog.txt`
- Bridge tooling state: `outputs/logs/bridge_status_drive.md`, `outputs/logs/artifact_recheck_drive.md`
- Tooling audit: `tools/notebook_tooling_audit.md`, `tools/run_cell_changelog.md`

## Limitations to disclose in the chapter
- Only one DB (`concert_singer`) is touched by smoke10/smoke25, so schema-linking benefit is bounded — most signal exists between *different* DBs, not within one.
- 4-bit quantisation may shift behaviour relative to fp16/bf16; not measured here.
- Single greedy decoding (no sampling, no self-consistency).
- No retrieval, planner, or repair loop yet (those belong to B2+).
- EX is execution-only; no logical-form / exact-match metric.
