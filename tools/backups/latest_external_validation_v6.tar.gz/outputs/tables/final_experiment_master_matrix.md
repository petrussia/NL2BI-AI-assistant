# Final Experiment Master Matrix (v6 — internal + external)
Generated: 2026-04-30T16:39:46.961409+00:00
Total rows: 46
  - internal_core: 38
  - external_validation: 8

|Run|Baseline|Ver|Model|Subset|Bench|n|EX|Exec|Mode|
|---|---|---|---|---|---|---|---|---|---|
|b0_llama_3p1_8b_bird_minidev_30|b0|—|Llama-3.1-8B|bird_minidev_30|EXT|30|0.1333|20|full_ex|
|b0_llama_3p1_8b_instruct_multidb30|b0|—|Llama-3.1-8B|multidb_30|core|30|0.8333|28|full_ex|
|b0_llama_3p1_8b_instruct_smoke10|b0|—|Llama-3.1-8B|smoke_10|core|10|0.8000|10|full_ex|
|b0_llama_3p1_8b_instruct_smoke25|b0|—|Llama-3.1-8B|smoke_25|core|25|0.6000|23|full_ex|
|b0_llama_3p1_8b_spider2lite_30|b0|—|Llama-3.1-8B|spider2lite_30|EXT|30|0.0000|0|prediction_only_structural_metrics|
|b0_multidb30_v2|b0|v2|Qwen2.5-Coder-7B|multidb_30|core|30|0.9333|30|full_ex|
|b0_qwen2p5_coder_14b_instruct_multidb30|b0|—|Qwen2.5-Coder-14B|multidb_30|core|30|0.8667|30|full_ex|
|b0_qwen2p5_coder_14b_instruct_smoke10|b0|—|Qwen2.5-Coder-14B|smoke_10|core|10|1.0000|10|full_ex|
|b0_qwen2p5_coder_14b_instruct_smoke25|b0|—|Qwen2.5-Coder-14B|smoke_25|core|25|0.9600|25|full_ex|
|b0_qwen2p5_coder_7b_bird_minidev_30|b0|—|Qwen2.5-Coder-7B|bird_minidev_30|EXT|30|0.2667|26|full_ex|
|b0_qwen2p5_coder_7b_spider2lite_30|b0|—|Qwen2.5-Coder-7B|spider2lite_30|EXT|30|0.0000|0|prediction_only_structural_metrics|
|b0_qwen_qwen2.5_7b_instruct_smoke10|b0|—|Qwen2.5-7B|smoke_10|core|10|0.6000|9|full_ex|
|b0_spider_smoke10|b0|—|Qwen2.5-Coder-7B|smoke_10|core|10|1.0000|10|full_ex|
|b0_spider_smoke25|b0|—|Qwen2.5-Coder-7B|smoke_25|core|25|0.9600|25|full_ex|
|b1_llama_3p1_8b_instruct_multidb30|b1|—|Llama-3.1-8B|multidb_30|core|30|0.7000|29|full_ex|
|b1_llama_3p1_8b_instruct_smoke10|b1|—|Llama-3.1-8B|smoke_10|core|10|0.9000|10|full_ex|
|b1_llama_3p1_8b_instruct_smoke25|b1|—|Llama-3.1-8B|smoke_25|core|25|0.7200|23|full_ex|
|b1_multidb30_v2|b1|v2|Qwen2.5-Coder-7B|multidb_30|core|30|0.7667|29|full_ex|
|b1_qwen2p5_coder_14b_instruct_multidb30|b1|—|Qwen2.5-Coder-14B|multidb_30|core|30|0.7667|28|full_ex|
|b1_qwen2p5_coder_14b_instruct_smoke10|b1|—|Qwen2.5-Coder-14B|smoke_10|core|10|1.0000|10|full_ex|
|b1_qwen2p5_coder_14b_instruct_smoke25|b1|—|Qwen2.5-Coder-14B|smoke_25|core|25|0.9200|25|full_ex|
|b1_qwen_qwen2.5_7b_instruct_smoke10|b1|—|Qwen2.5-7B|smoke_10|core|10|1.0000|10|full_ex|
|b1_spider_smoke10|b1|—|Qwen2.5-Coder-7B|smoke_10|core|10|1.0000|10|full_ex|
|b1_spider_smoke25|b1|—|Qwen2.5-Coder-7B|smoke_25|core|25|0.9600|25|full_ex|
|b2_spider_smoke10|b2|—|Qwen2.5-Coder-7B|smoke_10|core|10|0.7000|9|full_ex|
|b2v1_multidb30|b2v1|v1|Qwen2.5-Coder-7B|multidb_30|core|30|0.6333|26|full_ex|
|b2v1_spider_smoke10|b2v1|v1|Qwen2.5-Coder-7B|smoke_10|core|10|0.6000|8|full_ex|
|b2v2_llama_3p1_8b_bird_minidev_30|b2v2|v2|Llama-3.1-8B|bird_minidev_30|EXT|30|0.0667|16|full_ex|
|b2v2_llama_3p1_8b_spider2lite_30|b2v2|v2|Llama-3.1-8B|spider2lite_30|EXT|30|0.0000|0|prediction_only_structural_metrics|
|b2v2_multidb30|b2v2|v2|Qwen2.5-Coder-7B|multidb_30|core|30|0.8000|29|full_ex|
|b2v2_qwen2p5_coder_7b_bird_minidev_30|b2v2|v2|Qwen2.5-Coder-7B|bird_minidev_30|EXT|30|0.2000|22|full_ex|
|b2v2_qwen2p5_coder_7b_spider2lite_30|b2v2|v2|Qwen2.5-Coder-7B|spider2lite_30|EXT|30|0.0000|0|prediction_only_structural_metrics|
|b2v2_spider_smoke10|b2v2|v2|Qwen2.5-Coder-7B|smoke_10|core|10|0.8000|10|full_ex|
|b2v2_spider_smoke25|b2v2|v2|Qwen2.5-Coder-7B|smoke_25|core|25|0.9600|25|full_ex|
|b3_spider_smoke10|b3|—|Qwen2.5-Coder-7B|smoke_10|core|10|0.2000|2|full_ex|
|b3v1_multidb30|b3v1|v1|Qwen2.5-Coder-7B|multidb_30|core|30|0.4667|18|full_ex|
|b3v1_spider_smoke10|b3v1|v1|Qwen2.5-Coder-7B|smoke_10|core|10|0.3000|5|full_ex|
|b3v2_multidb30|b3v2|v2|Qwen2.5-Coder-7B|multidb_30|core|30|0.7333|29|full_ex|
|b3v2_spider_smoke10|b3v2|v2|Qwen2.5-Coder-7B|smoke_10|core|10|0.8000|10|full_ex|
|b3v2_spider_smoke25|b3v2|v2|Qwen2.5-Coder-7B|smoke_25|core|25|0.9600|25|full_ex|
|b4_final_multidb30|b4|final|Qwen2.5-Coder-7B|multidb_30|core|30|0.4667|18|full_ex|
|b4_final_spider_smoke10|b4|final|Qwen2.5-Coder-7B|smoke_10|core|10|0.3000|5|full_ex|
|b4_spider_smoke10|b4|—|Qwen2.5-Coder-7B|smoke_10|core|10|0.2000|2|full_ex|
|b4v2_multidb30|b4v2|v2|Qwen2.5-Coder-7B|multidb_30|core|30|0.7333|29|full_ex|
|b4v2_spider_smoke10|b4v2|v2|Qwen2.5-Coder-7B|smoke_10|core|10|0.8000|10|full_ex|
|b4v2_spider_smoke25|b4v2|v2|Qwen2.5-Coder-7B|smoke_25|core|25|0.9600|25|full_ex|
