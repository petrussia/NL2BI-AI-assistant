# Model Block Closure

Audited at: 2026-04-29T15:11:13.908936+00:00
GPU: NVIDIA L4, total VRAM 22563 MB, free 17209 MB at probe time.
HF_TOKEN present: **False** (source: none)
HF_TOKEN check vs Llama-3.1-8B-Instruct: **None** (no token to check)

## Mandatory model triple status

| Model | Status | Note |
|---|---|---|
| `Qwen/Qwen2.5-Coder-7B-Instruct` | ARTEFACTS_PRESENT | primary; multiple baselines on smoke10/25 |
| `meta-llama/Llama-3.1-8B-Instruct` | BLOCKED:no_HF_TOKEN | gated repo; needs HF_TOKEN configured in Colab kernel |
| `deepseek-ai/DeepSeek-Coder-V2-Lite-Instruct` | AVAILABLE_BUT_NOT_RUN | 16B MoE, ~13 GB in 4-bit, tight on L4 |

## Honest blocker statements

### Llama-3.1-8B-Instruct
- HF_TOKEN was MISSING at the time of this check.
- Token validation against the gated repo: None.
- Cannot load until a valid HF_TOKEN is provided in the Colab kernel:.
- **Workaround already in place:** comparator runs use `Qwen/Qwen2.5-7B-Instruct` (non-Coder, non-gated, same parameter count). See `outputs/metrics/b{0,1}_qwen_qwen2.5_7b_instruct_smoke10_metrics.csv`.

### DeepSeek-Coder-V2-Lite-Instruct
- Estimated 4-bit VRAM: 13000 MB on 22563 MB GPU.
- Buffer: 9563 MB after load (before inference KV cache).
- Verdict: **tight on L4** (works in principle but risks OOM on long contexts). Not attempted in this session because the BG was busy with B2_v1/B3_v1/B4_final on Qwen-Coder.
- **Recommendation:** load DeepSeek standalone in a fresh kernel (after freeing Qwen-Coder), B0 + B1 only on smoke10 (`make_prompt`/`make_b1_prompt` are model-agnostic).

## Final model matrix

See `outputs/tables/final_model_matrix.csv` for the actual baseline×subset×EX entries derived from metrics on Drive.
