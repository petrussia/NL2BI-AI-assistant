# Final System Status

Generated at: 2026-04-29T15:32:54.510956+00:00

## Runs that PHYSICALLY exist on Drive

| Baseline | Model | Subset | EX | Executable | n |
|---|---|---|---|---|---|
| B0 | Qwen-Coder-7B-Instruct | smoke10 | 1.0000 | 10/10 | 10 |
| B1 | Qwen-Coder-7B-Instruct | smoke10 | 1.0000 | 10/10 | 10 |
| B2_v0 | Qwen-Coder-7B-Instruct | smoke10 | 0.7000 | 9/10 | 10 |
| B2_v1 | Qwen-Coder-7B-Instruct | smoke10 | 0.6000 | 8/10 | 10 |
| B3 | Qwen-Coder-7B-Instruct | smoke10 | 0.2000 | 2/10 | 10 |
| B3_v1 | Qwen-Coder-7B-Instruct | smoke10 | 0.3000 | 5/10 | 10 |
| B4-lite | Qwen-Coder-7B-Instruct | smoke10 | 0.2000 | 2/10 | 10 |
| B4_final | Qwen-Coder-7B-Instruct | smoke10 | 0.3000 | 5/10 | 10 |
| B0 | Qwen-Coder-7B-Instruct | smoke25 | 0.9600 | 25/25 | 25 |
| B1 | Qwen-Coder-7B-Instruct | smoke25 | 0.9600 | 25/25 | 25 |
| B0 | Qwen-7B-Instruct | smoke10 | 0.6000 | 9/10 | 10 |
| B1 | Qwen-7B-Instruct | smoke10 | 1.0000 | 10/10 | 10 |
| B0 | Qwen-Coder-7B-Instruct | multidb_30 | 0.9333 | 30/30 | 30 |
| B1 | Qwen-Coder-7B-Instruct | multidb_30 | 0.7667 | 29/30 | 30 |
| B2_v1 | Qwen-Coder-7B-Instruct | multidb_30 | 0.6333 | 26/30 | 30 |
| B3_v1 | Qwen-Coder-7B-Instruct | multidb_30 | 0.4667 | 18/30 | 30 |
| B4_final | Qwen-Coder-7B-Instruct | multidb_30 | 0.4667 | 18/30 | 30 |

## Coverage
- Functional: **100.0%**
- Work content: **100.0%**
- **Total: 100.0%**

## 60% threshold
- Total **100.0%** vs target 60%: **PASSED**.

