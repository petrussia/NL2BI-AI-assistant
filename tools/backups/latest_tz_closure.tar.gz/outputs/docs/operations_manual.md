# Operations Manual

Date: 2026-04-29T15:03:36.172745+00:00.

## How to run an experiment from scratch

### 1. Bring up the bridge
1. Open `notebooks/example.ipynb` in VS Code with a Colab runtime attached.
2. Run cell `7f6bca53` (`AGENT_BRIDGE_SETUP`) — one Shift+Enter.
3. Output prints `BRIDGE_URL: https://<random>.trycloudflare.com` and `BRIDGE_READY`.
4. Locally, write the URL to `tools/.bridge_url` (or pass with `--url`).

### 2. Bootstrap kernel
```
python tools/exec_remote.py --code-file tools/remote_scripts/30_kernel_bootstrap.py --timeout 600
```
This re-mounts Drive, loads Spider, defines helpers, loads Qwen2.5-Coder-7B-Instruct in 4-bit.

### 3. Pick a run script
- Per-baseline runs: `tools/remote_scripts/<NN>_<run_name>.py`. Each one is a background-thread BG that returns instantly and writes to a task log.
- For long runs, fire-and-forget pattern: agent polls the task log via:
  ```
  python tools/exec_remote.py --code "from pathlib import Path; print(Path('/content/drive/.../bg_task_log.txt').read_text(encoding='utf-8')[-1500:])"
  ```

### 4. Verify run
- After `..._BG_DONE` marker appears, `outputs/metrics/<run_id>_metrics.csv` and `outputs/predictions/<run_id>_predictions.jsonl` are populated.
- Final ablation refresh:
  ```
  python tools/exec_remote.py --code-file tools/remote_scripts/38_final_ablation.py
  ```

## How to restore the bridge after it dies

The cloudflared quick-tunnel has no SLA; it can die after hours of uptime.

1. In notebook, re-run cell `7f6bca53`. Capture the new `BRIDGE_URL`.
2. Update `tools/.bridge_url` with the new URL.
3. Verify: `python tools/exec_remote.py --health` returns `{"ok": true, ...}`.
4. If kernel was also restarted (different `pid`), re-run the bootstrap script.

## How to restore Drive content (in case of mount-account mix-up)

If `/content/drive/MyDrive/diploma_plan_sql/` shows mostly empty content unexpectedly:

1. Verify by `python tools/exec_remote.py --code "from pathlib import Path; print(sorted(Path('/content/drive/MyDrive/diploma_plan_sql').iterdir()))"`.
2. If the tree is reduced to a few files, the user mounted a different Google account. Re-mount in the Colab UI under the correct account.
3. If the tree is gone for real, re-upload from the local mirror:
   ```
   python tools/exec_remote.py --code-file tools/remote_scripts/32_upload_local_mirror.py --timeout 300
   python tools/exec_remote.py --code-file tools/remote_scripts/31_restore_drive_spider.py --timeout 300
   ```
4. Re-bootstrap kernel.

## How to reproduce a published artefact (e.g., `outputs/tables/final_ablation_summary.md`)

1. Ensure all underlying metrics CSVs exist: `ls outputs/metrics/`.
2. Run `python tools/exec_remote.py --code-file tools/remote_scripts/38_final_ablation.py`.
3. The script reads `outputs/metrics/<prefix>_metrics.csv` for each baseline / subset and re-derives the ablation.

## Failure handling

- **Bridge HTTP 524 (Cloudflare timeout)** → cell may still be running on Colab side; check task log.
- **Kernel disconnect** → re-fire bootstrap. Predictions saved incrementally survive partial runs.
- **OOM during model load** → swap model strategy: free current model with `del model; gc.collect(); torch.cuda.empty_cache()`, then load smaller candidate.
- **HF gated repo (Llama)** → set `HF_TOKEN` in Colab kernel `os.environ["HF_TOKEN"] = "..."` BEFORE loading.
- **SQLite ProgrammingError on subset items** → check `error_message` field in predictions JSONL; usually the model produced syntax-invalid SQL.
- **Plan parse failures spike for B2/B3** → planner over-prompted; reduce knowledge channel verbosity (B3_v1 fix).

## Daily checklist

1. Bridge alive? `python tools/exec_remote.py --health`.
2. Kernel state? `python tools/exec_remote.py --code-file tools/remote_scripts/_check_kernel_state.py`.
3. Drive content sane? `python tools/exec_remote.py --code "from pathlib import Path; r=Path('/content/drive/MyDrive/diploma_plan_sql'); print({p.name: sum(1 for _ in p.rglob('*') if _.is_file()) for p in r.iterdir() if p.is_dir()})"`.
4. Local mirror up to date? `Get-ChildItem D:\HSE\Диплом\NL2BI-AI-assistant\outputs -Recurse | Measure-Object`.
