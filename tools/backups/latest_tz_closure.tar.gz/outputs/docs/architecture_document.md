# System Architecture Document

Date: 2026-04-29T15:03:36.172745+00:00.
Project: NL2BI-AI-assistant — natural-language to SQL technology for extracting and processing data from a heterogeneous source array.

## High-level architecture

```
[NL question] -> [Query Analysis] -> [Schema Retrieval] -> [Knowledge Retrieval]
                                          \____________  ___________/
                                                      \/
                                                  [Planner]
                                                      |
                                                 [Plan Validator]
                                                      |
                                              [SQL Synthesizer]
                                                      |
                              [Validation Gate (SELECT-only / AST guard)]
                                                      |
                                  [Multi-Candidate / Bounded Repair]
                                                      |
                                                 [Executor]
                                                      |
                                                [Postprocess]
                                                      |
                                       [Analytics Handoff Payload]
```

Diagrams: `outputs/plots/system_architecture_overview.png`,
`outputs/plots/ablation_pipeline_ladder.png`.

## Components

| Layer | Component | Module | Closes |
|---|---|---|---|
| 1. NL analysis | Query Analyzer | `repo/src/evaluation/query_analysis.py` | ТЗ 2.2.1 |
| 2. Source linking | Schema Linker (lexical) | `repo/src/evaluation/baselines.py` | ТЗ 2.2.2 |
| 2b. Cross-DB retrieval | Lexical retrieval helper | `repo/src/evaluation/retrieval.py` | ТЗ 2.2.2 (extended) |
| 2c. Knowledge channel (proxy) | per-table doc proxy | `repo/src/evaluation/baselines_b3.py` | ТЗ 2.2.2 (extended) |
| 3. Planner | JSON Plan emitter | `repo/src/evaluation/baselines_b2.py` (`baselines_b2_v1.py`, `baselines_b3.py`) | ТЗ 2.2.4 (formalisation) |
| 4. Plan validator | jsonschema | `repo/docs/plan_schema.json`, `plan_schema_v1.json` | ТЗ 2.2.4 |
| 5. SQL synthesizer | Plan→SQL prompt | `baselines_b2*.py`, `baselines_b3.py` | ТЗ 2.2.3 |
| 6. Validation gate | SELECT-only AST guard | `repo/src/evaluation/baselines_b4.py::is_safe_select` | ТЗ 2.2.3 (safety) |
| 7. Multi-candidate / Repair | sampling + consistency selection | `baselines_b4.py::consistency_pick`, `make_repair_prompt` | ТЗ 2.2.4 |
| 8. Executor | SQLite execution + 8s timeout | `func_timeout`-wrapped `execute_sql` | ТЗ 2.2.3 (performance) |
| 9. Postprocess | normalize + summary | `repo/src/evaluation/postprocess.py` | ТЗ 2.2.5 |
| 10. Analytics handoff | JSON+CSV export with v1 contract | `repo/src/evaluation/postprocess.py::build_analytics_payload` | ТЗ 2.2.6 |
| 11. Bridge tooling | Flask + cloudflared in Colab kernel | notebook cell `7f6bca53` + `tools/exec_remote.py` | infra |

## Baseline ladder (B0 → B4-lite) and where each component is exercised

| Baseline | Layers used (in addition to B0) |
|---|---|
| B0 | layers 5 (with full schema), 8, 9 (optional), 10 (optional) |
| B1 | + layer 2 (schema linker) |
| B2 (v0/v1) | + layers 3, 4, 5b (plan→SQL) |
| B3 | + layers 2b, 2c (dual retrieval), reuse of 3+4+5 |
| B4-lite | + layers 6, 7, bounded repair |

## Data flow (per item)

1. NL question is consumed by the **Query Analyzer** → `QueryAnalysis` dict.
2. The Schema Linker selects relevant tables (lexical scoring within DB).
3. (B3+) The Knowledge channel attaches synthetic per-table documentation snippets (proxy docs derived from schema metadata).
4. The Planner emits a **JSON Plan** validated against `plan_schema_v1.json`.
5. The SQL Synthesizer maps Plan → SQL.
6. The Validation Gate rejects forbidden statements.
7. (B4-lite) Multi-candidate sampling + consistency selection; bounded repair if no executable.
8. The Executor runs SQL against SQLite with 8 s timeout; rows returned.
9. Postprocess normalizes rows and computes per-column summary.
10. Analytics Handoff serializes the payload as JSON + CSV under `outputs/analytics_handoff/`.

## Constraints and assumptions

- **Single GPU runtime** (NVIDIA L4, 23 GB VRAM). 4-bit `nf4` quantization for all 7B / 8B models.
- **Single Colab Drive** as the canonical artefact store.
- **Lexical retrieval only** (no embeddings) — by design, to keep B1/B3 baselines auditable.
- **Greedy decoding** for plan + single-candidate SQL; **sampling (T=0.7, top_p=0.95)** only for B4-lite multi-candidate.
- **SQLite** is the executor; benchmark is **Spider dev split** (1034 questions, 166 DBs).
- **EX (Execution Match)** is the primary metric; `executable_count`, `plan_valid_count`, `avg_reduction_ratio` are auxiliary.

## Failure modes (documented)

- Cloudflare quick-tunnel can recycle without notice — reconnect by re-running cell `7f6bca53` and updating `tools/.bridge_url`.
- Drive mount can show different content if user mounts a different Google account — restore via `tools/remote_scripts/31_restore_drive_spider.py` + `32_upload_local_mirror.py`.
- B3 planner overload on tiny DBs (fixed in B3_v1 via adaptive retrieval).
- Llama-3.1-8B-Instruct is gated; needs `HF_TOKEN` configured in the Colab kernel. Fallback comparator: Qwen2.5-7B-Instruct (non-Coder).
