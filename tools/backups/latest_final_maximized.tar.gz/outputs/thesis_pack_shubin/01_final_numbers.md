# 01 — Final numbers (Shubin)

_Generated: 2026-04-30T12:28:47.260219+00:00_

## Headline EX (Execution Match) — copy-pasteable for ВКР tables

### Single-DB smoke subsets

| Baseline | Model | smoke_10 | smoke_25 |
|---|---|---|---|
| B0 | Qwen2.5-Coder-7B-Instruct | 1.0000 (10/10) | 0.9600 (24/25) |
| B1 | Qwen2.5-Coder-7B-Instruct | 1.0000 (10/10) | 0.9600 (24/25) |
| B2_v0 | Qwen2.5-Coder-7B-Instruct | 0.7000 (7/10) | — |
| B2_v1 | Qwen2.5-Coder-7B-Instruct | 0.6000 (6/10) | — |
| B2_v2 | Qwen2.5-Coder-7B-Instruct | 0.8000 (8/10) | — |
| B3_v1 | Qwen2.5-Coder-7B-Instruct | 0.3000 (3/10) | — |
| B3_v2 | Qwen2.5-Coder-7B-Instruct | 0.8000 (8/10) | — |
| B4_final | Qwen2.5-Coder-7B-Instruct | 0.3000 (3/10) | — |
| B4_v2 | Qwen2.5-Coder-7B-Instruct | 0.8000 (8/10) | — |
| B0 | Qwen2.5-7B-Instruct (cross-model) | 0.6000 (6/10) | — |
| B1 | Qwen2.5-7B-Instruct (cross-model) | 1.0000 (10/10) | — |
| B0 | Llama-3.1-8B-Instruct | 0.8000 (8/10) | — |
| B1 | Llama-3.1-8B-Instruct | 0.9000 (9/10) | — |
| B0 | Qwen2.5-Coder-14B-Instruct | — | — |
| B1 | Qwen2.5-Coder-14B-Instruct | — | — |

### multidb_30 (master scientific slice — heterogeneous schemas across 6 DBs)

| Baseline | Model | EX |
|---|---|---|
| B0 | Qwen2.5-Coder-7B-Instruct | 0.9333 (28/30) |
| B1 | Qwen2.5-Coder-7B-Instruct | 0.7667 (23/30) |
| B2_v1 | Qwen2.5-Coder-7B-Instruct | 0.6333 (19/30) |
| B2_v2 | Qwen2.5-Coder-7B-Instruct | 0.8000 (24/30) |
| B3_v1 | Qwen2.5-Coder-7B-Instruct | 0.4667 (14/30) |
| B3_v2 | Qwen2.5-Coder-7B-Instruct | 0.7333 (22/30) |
| B4_final | Qwen2.5-Coder-7B-Instruct | 0.4667 (14/30) |
| B4_v2 | Qwen2.5-Coder-7B-Instruct | 0.7333 (22/30) |
| B0 | Qwen2.5-Coder-14B-Instruct | — |
| B1 | Qwen2.5-Coder-14B-Instruct | — |

## Strongest configurations (recommendation for production / defense)

- **Best direct baseline:** B0 + Qwen2.5-Coder-7B-Instruct (smoke_10 = 1.0, smoke_25 = 0.96, multidb_30 = 0.9333).
- **Best layered baseline:** B3_v2 / B4_v2 + Qwen2.5-Coder-7B-Instruct (smoke_10 = 0.80, multidb_30 = 0.7333). Layered stack adds engineering safety (validation, repair, multi-cand, AST guard) but does not exceed B0 on this benchmark.
- **Best cross-model substitute:** Llama-3.1-8B-Instruct B1 (smoke_10 = 0.90) — competitive with Coder-7B on reduced-schema prompts.
