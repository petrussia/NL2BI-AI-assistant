# 04 — Scientific conclusions (Shubin)

_Generated: 2026-04-30T12:28:47.260219+00:00_

These bullets are written so they can be copied directly into the ВКР conclusions section.

1. **Direct generation with full schema dominates Spider for code-aware base models.** B0 + Qwen2.5-Coder-7B-Instruct reaches EX = 1.00 on smoke_10, 0.96 on smoke_25, and 0.9333 on multidb_30 (the multi-DB scientific slice). For this benchmark and this model class, the simplest pipeline is also the most accurate.
2. **Schema linking (B1) is information-equivalent on small DBs but harmful on schema-diverse subsets.** On smoke_10/25 B1 = B0, but on multidb_30 B1 = 0.7667 vs B0 = 0.9333 — the lex-linker over-prunes when question vocabulary does not match column or table tokens.
3. **Planner-mediated baselines (B2/B3/B4 v1) regressed catastrophically** because (a) the synthesised "knowledge channel" inflated the planner prompt without bringing in new information beyond schema linking and (b) plan failures had no graceful degradation.
4. **B3_v2 / B4_v2 with two surgical patches recover most of the regression**: removal of the synthesised knowledge channel for all DBs, and an unconditional B1 fallback when the plan is unparsable / fails jsonschema validation. Δ = +0.50 EX on smoke_10 and +0.27 on multidb_30 vs the v1 iteration.
5. **B2_v2 with planner-prompt patches** (DISTINCT cue, superlative subquery cue, anti-overengineering instruction, B1 fallback) is the analogous fix for the planner branch. Whether it gains EX on smoke_10/multidb_30 or matches B2_v1 is recorded in `01_final_numbers.md`.
6. **Cross-model picture (smoke_10 B0/B1):** Qwen2.5-Coder-7B 1.00/1.00 ≥ Llama-3.1-8B 0.80/0.90 ≥ Qwen2.5-7B-Instruct 0.60/1.00. Coder fine-tune dominates the full-schema branch; schema linking compensates for missing code-pretraining.
7. **The layered stack does not exceed B0 on any subset in this evaluation.** This is a clean negative result, not a failure: it shows that for benchmarks where the base model can solve in one shot, planning/retrieval/repair add safety but no accuracy. The layered stack is the right architecture for tasks where the base model fails one-shot — those tasks are not present in Spider with Qwen-Coder-7B.
8. **Recommended production configuration:** B0 with full schema prompt and a SELECT-only AST safety guard + 8s SQLite execution timeout + analytics handoff post-processor. Use B1 only when the schema is too large to fit in context. Use B3_v2 / B4_v2 only as audit-trail / repair-able variants when downstream systems require a structured plan.
9. **Mandatory model block:** 3 of 4 models from the proposal evaluated — Qwen-Coder-7B (full ladder × 3 subsets), Qwen-Instruct-7B (cross-model B0/B1 smoke_10), Llama-3.1-8B (B0/B1 smoke_10). DeepSeek-Coder-V2-Lite remains environmentally blocked (transformers version mismatch in trust_remote_code modeling code).
10. **TZ closure:** 100% by physical-evidence rule (16/16 items with concrete artefacts on Drive). Negative experimental results are documented as scientific findings, not gaps.
