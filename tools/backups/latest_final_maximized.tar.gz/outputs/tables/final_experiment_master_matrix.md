# Final Experiment Master Matrix
Generated: 2026-04-30T12:28:42.949200+00:00

|Run|Baseline|Model|Subset|n|EX|Executable|Plan-valid|Avg-red|Fallback|
|---|---|---|---|---|---|---|---|---|---|
|b0_llama_3p1_8b_instruct_smoke10|b0|meta-llama/Llama-3.1-8B|smoke_10|10|0.8000|10|—|—|—|
|b0_multidb30_v2|b0|Qwen2.5-Coder-7B|multidb_30|30|0.9333|30|—|—|—|
|b0_qwen_qwen2.5_7b_instruct_smoke10|b0|Qwen2.5-7B|smoke_10|10|0.6000|9|—|—|—|
|b0_spider_smoke10|b0|Qwen2.5-Coder-7B|smoke_10|10|1.0000|10|—|—|—|
|b0_spider_smoke25|b0|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|—|—|
|b1_llama_3p1_8b_instruct_smoke10|b1|meta-llama/Llama-3.1-8B|smoke_10|10|0.9000|10|—|0.475|—|
|b1_multidb30_v2|b1|Qwen2.5-Coder-7B|multidb_30|30|0.7667|29|—|0.5527777777777777|—|
|b1_qwen_qwen2.5_7b_instruct_smoke10|b1|Qwen2.5-7B|smoke_10|10|1.0000|10|—|0.475|—|
|b1_spider_smoke10|b1|Qwen2.5-Coder-7B|smoke_10|10|1.0000|10|—|0.475|—|
|b1_spider_smoke25|b1|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|0.58|—|
|b2_spider_smoke10|b2|Qwen2.5-Coder-7B|smoke_10|10|0.7000|9|9|0.475|—|
|b2v1_multidb30|b2v1|Qwen2.5-Coder-7B|multidb_30|30|0.6333|26|28|0.5527777777777777|—|
|b2v1_spider_smoke10|b2v1|Qwen2.5-Coder-7B|smoke_10|10|0.6000|8|8|0.475|—|
|b2v2_multidb30|b2v2|Qwen2.5-Coder-7B|multidb_30|30|0.8000|29|—|—|b1_on_invalid_plan|
|b2v2_spider_smoke10|b2v2|Qwen2.5-Coder-7B|smoke_10|10|0.8000|10|—|—|b1_on_invalid_plan|
|b3_spider_smoke10|b3|Qwen2.5-Coder-7B|smoke_10|10|0.2000|2|2|0.475|—|
|b3v1_multidb30|b3v1|Qwen2.5-Coder-7B|multidb_30|30|0.4667|18|18|0.5527777777777777|—|
|b3v1_spider_smoke10|b3v1|Qwen2.5-Coder-7B|smoke_10|10|0.3000|5|5|0.475|—|
|b3v2_multidb30|b3v2|Qwen2.5-Coder-7B|multidb_30|30|0.7333|29|—|0.5527777777777777|b1_on_invalid_plan|
|b3v2_spider_smoke10|b3v2|Qwen2.5-Coder-7B|smoke_10|10|0.8000|10|—|0.475|b1_on_invalid_plan|
|b4_final_multidb30|b4|Qwen2.5-Coder-7B|multidb_30|30|0.4667|18|18|0.5527777777777777|—|
|b4_final_spider_smoke10|b4|Qwen2.5-Coder-7B|smoke_10|10|0.3000|5|5|0.475|—|
|b4_spider_smoke10|b4|Qwen2.5-Coder-7B|smoke_10|10|0.2000|2|2|0.475|—|
|b4v2_multidb30|b4v2|Qwen2.5-Coder-7B|multidb_30|30|0.7333|29|—|0.5527777777777777|b1_on_invalid_or_no_executable|
|b4v2_spider_smoke10|b4v2|Qwen2.5-Coder-7B|smoke_10|10|0.8000|10|—|0.475|b1_on_invalid_or_no_executable|
