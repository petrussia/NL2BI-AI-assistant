# Final negative-result analysis (post v3)

**Generated:** 2026-04-30T12:31:29.037908+00:00

## Direct EX comparison

| Subset | B2_v1 | **B2_v2** | Δ B2_v2−B2_v1 | B3_v1 | B3_v2 | Δ B3_v2−B3_v1 | B4_final | B4_v2 | Δ B4_v2−B4final |
|---|---|---|---|---|---|---|---|---|---|
| smoke_10  | 0.6000 (6/10) | **0.8000 (8/10)** | (~+0.20) | 0.3000 (3/10) | 0.8000 (8/10) | +0.50 | 0.3000 (3/10) | 0.8000 (8/10) | +0.50 |
| multidb_30 | 0.6333 (19/30) | **0.8000 (24/30)** | (~+0.17) | 0.4667 (14/30) | 0.7333 (22/30) | +0.27 | 0.4667 (14/30) | 0.7333 (22/30) | +0.27 |

## Comparison vs direct B0/B1 (the real bar)

| Subset | B0 | B1 | best layered v2 | layered − B1 |
|---|---|---|---|---|
| smoke_10  | 1.0000 (10/10) | 1.0000 (10/10) | 0.80 (B2_v2/B3_v2/B4_v2) | −0.20 |
| multidb_30 | 0.9333 (28/30) | 0.7667 (23/30) | **0.8000 (24/30) (B2_v2)** | **+0.0333** |

## Interpretation

The headline negative result of the prior iteration ("layered baselines never
beat direct") is now **partially overturned**: B2_v2 + Qwen-Coder-7B reaches
EX = 0.80 on multidb_30, slightly above B1 = 0.7667 (+0.0333). This is the
first and only configuration in the project where a structured baseline wins
over its direct counterpart, on the multi-DB scientific slice that matters
most.

The mechanism is simple: the v2 design ensures `EX(layered) >= EX(B1) − sql_noise`
via the unconditional B1 fallback, and on the items where the planner *does*
produce a valid plan, the SQL synthesis with full schema + plan + DISTINCT/
superlative cues + anti-overengineering instruction is marginally better than
single-shot B1.

The original headline still holds vs B0: **no layered baseline beats B0 + Qwen-Coder-7B on any subset**.
B0 saturates this benchmark; layered planning only pays off when the base
model fails one-shot, which is rare on Spider with a code-aware base model.

## Defense narrative

- "We initially saw the layered planner stack regress catastrophically (B3, B4-lite at 0.20–0.30 EX). We diagnosed two causes: prompt noise from a synthesised knowledge channel, and lack of graceful degradation when the planner fails. We fixed both: removed the knowledge channel and added an unconditional B1 fallback on plan-or-execution failure. The fix recovered +0.50 EX on smoke_10 and +0.27 on multi-DB."
- "On the multi-DB scientific slice, the patched planner (B2_v2) is the first configuration in the project that beats B1 (0.80 vs 0.7667). This shows that the planner branch is salvageable when paired with a safety net — but the gain is small."
- "The strongest direct configuration (B0 + Qwen-Coder-7B) still dominates by 0.13 EX on multi-DB. We recommend B0 for production and B2_v2 as the audit-trail variant when downstream systems need a structured plan."
