# Final scientific findings

**Generated:** 2026-04-30T12:28:43.169734+00:00

## 1. Best direct baseline (B0/B1)
- smoke_10: —
- multidb_30: —

## 2. Best retrieval/planning baseline (B2*/B3*/B4*)
- smoke_10: `b0_spider_smoke10` EX=1.0000 (n=10)
- multidb_30: `b0_multidb30_v2` EX=0.9333 (n=30)

## 3. Where schema linking helps / hurts
- On smoke_10/25 with Qwen-Coder-7B: B0 = B1 = 1.0 / 0.96. Schema linking is
  information-equivalent: the lex linker reduces the prompt by ~50% with no
  EX cost on small Spider DBs.
- On multidb_30 (6 distinct DBs, more diverse schemas): B0 = 0.93, B1 = 0.77.
  The lex linker over-prunes when the question vocabulary does not lexically
  match column or table names. **Schema linking actively hurts on
  schema-diverse benchmarks.**

## 4. Where the planner helps / hurts
- The B2/B3/B4 family **never beats B0** on any subset evaluated.
- B3 and B4-lite catastrophically regressed (EX = 0.20 on smoke_10) because the
  synthesised "knowledge channel" inflated the planner prompt without adding
  signal beyond what schema linking already carried.
- B3_v1 / B4_final partially fixed this with adaptive policy, but the planner
  itself remained a bottleneck: when the JSON was malformed, the entire
  pipeline failed for that item.
- B3_v2 / B4_v2 add an unconditional **B1 fallback** at the planner-failure
  boundary, which guarantees that the layered baseline cannot regress *below*
  B1. This is a structural fix, not an accuracy improvement.

## 5. What multidb_30 reveals
The multi-DB subset is the hardest test in this evaluation slice.
On it, B0 (full schema, single-shot) **dominates everything else by 0.16+ EX
points**. This is the cleanest evidence in the project that, for a benchmark
where the base model can already read the full schema and write correct SQL,
no amount of schema linking, planning, or repair recovers lost ground —
they each remove information or add failure modes.

## 6. How to interpret the negative results
The diploma's experimental contribution is therefore TWO-FOLD:

1. **Positive contribution (engineering):** A complete NL→SQL pipeline with
   query analysis, lex schema linking, JSON-validated plan generation, dual
   retrieval, multi-candidate sampling with consistency selection, bounded
   repair, AST-level safety guard, post-processing and analytics handoff.
   Every layer is implemented and exercised.

2. **Negative contribution (scientific):** On Spider with a strong code-aware
   base model (Qwen-Coder-7B-Instruct in 4-bit), every layer above B0/B1
   either *does not improve* EX or *actively reduces* it. The right
   architecture for this task on this hardware is **B0 with full schema
   prompt, single-shot SQL, with a SELECT-only AST guard and execution
   sandbox**. The planner stack only pays off on tasks where single-shot
   SQL is already failing, which is *not* the case on Spider for this model.

## 7. What can be claimed at defense
- "The proposed pipeline is fully implemented and reproducible." ✅
- "On Spider+Qwen-Coder, the simplest direct baseline saturates the
  benchmark. The retrieval/planner stack adds engineering safety (validation,
  repair, fallback) but does not improve EX, and on harder schema-diverse
  subsets it can hurt." ✅
- "The mandatory model block is partially closed: Qwen-Coder fully evaluated
  across 3 subsets, Qwen-Instruct cross-model on 1 subset; Llama-3.1-8B
  blocked by HF_TOKEN absence; DeepSeek-V2-Lite blocked by transformers
  version mismatch in the trust-remote-code modeling file." ✅
- We can NOT honestly claim "the planner stack improves accuracy on this
  benchmark." That would be a misrepresentation. Defense narrative must own
  the negative result and frame it as a finding about benchmark difficulty
  vs base-model capability.
