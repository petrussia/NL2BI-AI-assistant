# Final Experiment Master Matrix (v5)
Generated: 2026-04-30T15:44:15.321995+00:00
Total rows: 38

|Run|Baseline|Ver|Model|Subset|n|EX|Exec|Plan-valid|Avg-red|Fallback|Status|
|---|---|---|---|---|---|---|---|---|---|---|---|
|b0_llama_3p1_8b_instruct_multidb30|b0|—|Llama-3.1-8B|multidb_30|30|0.8333|28|—|—|—|completed|
|b0_llama_3p1_8b_instruct_smoke10|b0|—|Llama-3.1-8B|smoke_10|10|0.8000|10|—|—|—|completed|
|b0_llama_3p1_8b_instruct_smoke25|b0|—|Llama-3.1-8B|smoke_25|25|0.6000|23|—|—|—|completed|
|b0_multidb30_v2|b0|v2|Qwen2.5-Coder-7B|multidb_30|30|0.9333|30|—|—|—|completed|
|b0_qwen2p5_coder_14b_instruct_multidb30|b0|—|Qwen2.5-Coder-14B|multidb_30|30|0.8667|30|—|—|—|completed|
|b0_qwen2p5_coder_14b_instruct_smoke10|b0|—|Qwen2.5-Coder-14B|smoke_10|10|1.0000|10|—|—|—|completed|
|b0_qwen2p5_coder_14b_instruct_smoke25|b0|—|Qwen2.5-Coder-14B|smoke_25|25|0.9600|25|—|—|—|completed|
|b0_qwen_qwen2.5_7b_instruct_smoke10|b0|—|Qwen2.5-7B|smoke_10|10|0.6000|9|—|—|—|completed|
|b0_spider_smoke10|b0|—|Qwen2.5-Coder-7B|smoke_10|10|1.0000|10|—|—|—|completed|
|b0_spider_smoke25|b0|—|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|—|—|completed|
|b1_llama_3p1_8b_instruct_multidb30|b1|—|Llama-3.1-8B|multidb_30|30|0.7000|29|—|0.5527777777777777|—|completed|
|b1_llama_3p1_8b_instruct_smoke10|b1|—|Llama-3.1-8B|smoke_10|10|0.9000|10|—|0.475|—|completed|
|b1_llama_3p1_8b_instruct_smoke25|b1|—|Llama-3.1-8B|smoke_25|25|0.7200|23|—|0.58|—|completed|
|b1_multidb30_v2|b1|v2|Qwen2.5-Coder-7B|multidb_30|30|0.7667|29|—|0.5527777777777777|—|completed|
|b1_qwen2p5_coder_14b_instruct_multidb30|b1|—|Qwen2.5-Coder-14B|multidb_30|30|0.7667|28|—|0.5527777777777777|—|completed|
|b1_qwen2p5_coder_14b_instruct_smoke10|b1|—|Qwen2.5-Coder-14B|smoke_10|10|1.0000|10|—|0.475|—|completed|
|b1_qwen2p5_coder_14b_instruct_smoke25|b1|—|Qwen2.5-Coder-14B|smoke_25|25|0.9200|25|—|0.58|—|completed|
|b1_qwen_qwen2.5_7b_instruct_smoke10|b1|—|Qwen2.5-7B|smoke_10|10|1.0000|10|—|0.475|—|completed|
|b1_spider_smoke10|b1|—|Qwen2.5-Coder-7B|smoke_10|10|1.0000|10|—|0.475|—|completed|
|b1_spider_smoke25|b1|—|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|0.58|—|completed|
|b2_spider_smoke10|b2|—|Qwen2.5-Coder-7B|smoke_10|10|0.7000|9|9|0.475|—|completed|
|b2v1_multidb30|b2v1|v1|Qwen2.5-Coder-7B|multidb_30|30|0.6333|26|28|0.5527777777777777|—|completed|
|b2v1_spider_smoke10|b2v1|v1|Qwen2.5-Coder-7B|smoke_10|10|0.6000|8|8|0.475|—|completed|
|b2v2_multidb30|b2v2|v2|Qwen2.5-Coder-7B|multidb_30|30|0.8000|29|—|—|b1_on_invalid_plan|completed|
|b2v2_spider_smoke10|b2v2|v2|Qwen2.5-Coder-7B|smoke_10|10|0.8000|10|—|—|b1_on_invalid_plan|completed|
|b2v2_spider_smoke25|b2v2|v2|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|—|b1_on_invalid_plan|completed|
|b3_spider_smoke10|b3|—|Qwen2.5-Coder-7B|smoke_10|10|0.2000|2|2|0.475|—|completed|
|b3v1_multidb30|b3v1|v1|Qwen2.5-Coder-7B|multidb_30|30|0.4667|18|18|0.5527777777777777|—|completed|
|b3v1_spider_smoke10|b3v1|v1|Qwen2.5-Coder-7B|smoke_10|10|0.3000|5|5|0.475|—|completed|
|b3v2_multidb30|b3v2|v2|Qwen2.5-Coder-7B|multidb_30|30|0.7333|29|—|0.5527777777777777|b1_on_invalid_plan|completed|
|b3v2_spider_smoke10|b3v2|v2|Qwen2.5-Coder-7B|smoke_10|10|0.8000|10|—|0.475|b1_on_invalid_plan|completed|
|b3v2_spider_smoke25|b3v2|v2|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|0.58|b1_on_invalid_plan|completed|
|b4_final_multidb30|b4|final|Qwen2.5-Coder-7B|multidb_30|30|0.4667|18|18|0.5527777777777777|—|completed|
|b4_final_spider_smoke10|b4|final|Qwen2.5-Coder-7B|smoke_10|10|0.3000|5|5|0.475|—|completed|
|b4_spider_smoke10|b4|—|Qwen2.5-Coder-7B|smoke_10|10|0.2000|2|2|0.475|—|completed|
|b4v2_multidb30|b4v2|v2|Qwen2.5-Coder-7B|multidb_30|30|0.7333|29|—|0.5527777777777777|b1_on_invalid_or_no_executable|completed|
|b4v2_spider_smoke10|b4v2|v2|Qwen2.5-Coder-7B|smoke_10|10|0.8000|10|—|0.475|b1_on_invalid_or_no_executable|completed|
|b4v2_spider_smoke25|b4v2|v2|Qwen2.5-Coder-7B|smoke_25|25|0.9600|25|—|0.58|b1_on_invalid_or_no_executable|completed|
