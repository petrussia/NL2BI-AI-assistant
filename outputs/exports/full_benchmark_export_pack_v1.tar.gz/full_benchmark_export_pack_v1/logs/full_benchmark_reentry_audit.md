# Full benchmark reentry audit + plan

**Generated:** 2026-04-30T23:42:09.249666+00:00
**Bridge:** live, A100 80 GB free
**HF_TOKEN:** SET, Drive mounted
**Existing master matrix:** 127 rows (sample-size runs only — smoke_10/25/multidb_30/minidev_30/spider2lite_30)

## Physical benchmark sizes (verified)
| Benchmark | n examples | unique DBs | Notes |
|---|---|---|---|
| **Spider dev FULL** | **1034** | 20 | All have gold SQL; 166 SQLite DB files |
| **BIRD Mini-Dev FULL** | **500** | 11 | 498/500 have evidence; SQLite gold execution available |
| **Spider 2.0-Lite FULL** | **547** | 158 | Structural-only (gold targets BigQuery/Snowflake) |

## Compute reality check
- One generation on A100 BF16 7B model ≈ 2 sec
- Full sweep (5 baselines × 6+ models × 2081 ex) ≈ **62,000 generations × 2 sec = 35 hours of compute** for P0/P1 models alone
- This exceeds a single agent session's effective wall time

## Decision: critical-evidence subset this iteration

Run **9 critical cells** = ~3,000 generations × ~2-3 sec = **~3-4 hours runtime** on A100 BF16:
- Qwen-Coder-7B × {B0, B1_v3, B3_v4} × Spider dev full (3 × 1034 = 3102 gen)
- Qwen-Coder-7B × {B0, B1_v3, B3_v4, B2_v4} × BIRD full (4 × 500 = 2000 gen)
- Qwen-Coder-7B × {B0, B3_v4} × Spider 2.0-Lite full structural (2 × 547 = 1094 gen)

**Why this subset:** directly tests the v9 claim (planner hurts, retrieval-only wins) on FULL benchmarks for the incumbent model. Other models / baselines documented as deferred future work.

## Plan summary
- Planned (this iteration): 9
- Deferred (multi-session): 30
- Blocked (DeepSeek): 1

## Resumability
All runs use predictions_jsonl that's incrementally written per-item (one line per example, flushed). On resume, the runner counts existing lines and skips completed examples.

## Ground rules
- No fake EX on Spider 2.0-Lite (structural-only metrics only).
- DeepSeek not attempted in current kernel.
- Old smoke/sample runs preserved as "sample_run" category in master matrix; full runs added with new "full" suffix.
